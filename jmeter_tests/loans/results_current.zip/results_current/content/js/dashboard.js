/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 48.3125, "KoPercent": 51.6875};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.3854761904761905, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5, 500, 1500, "GetUserDepartmentLN"], "isController": false}, {"data": [0.87, 500, 1500, "View Loan Request"], "isController": true}, {"data": [0.0, 500, 1500, "Upload Loan Forms"], "isController": false}, {"data": [0.0, 500, 1500, "Edit Load Request"], "isController": true}, {"data": [0.89, 500, 1500, "ListActiveLoanTypes"], "isController": false}, {"data": [0.49, 500, 1500, "GetUserLoansAccessLevel"], "isController": false}, {"data": [0.35, 500, 1500, "Delete  Loan Request"], "isController": true}, {"data": [0.5, 500, 1500, "HardDeleteLoan"], "isController": false}, {"data": [0.52, 500, 1500, "Get UserId from Token"], "isController": false}, {"data": [0.0, 500, 1500, "Load Time Of Loans Page"], "isController": true}, {"data": [0.0, 500, 1500, "Create Loan Request"], "isController": false}, {"data": [0.0, 500, 1500, "Update Loan Request"], "isController": false}, {"data": [0.235, 500, 1500, "ListEmployeeIdentificationLN"], "isController": false}, {"data": [0.57, 500, 1500, "GET_SINGLE_EMPLOYEE_LOANS"], "isController": false}, {"data": [0.0, 500, 1500, "Send a Loan Request"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1600, 827, 51.6875, 381.6368750000003, 0, 7430, 275.0, 701.9000000000001, 1021.2999999999975, 1981.6600000000003, 0.5418993164617497, 0.7669036257255524, 0.6005646141058762], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GetUserDepartmentLN", 100, 48, 48.0, 298.4699999999999, 132, 1765, 235.0, 370.30000000000007, 880.3499999999947, 1762.4199999999987, 0.034124731353052426, 0.031245457145138624, 0.03359953040957185], "isController": false}, {"data": ["View Loan Request", 100, 0, 0.0, 468.35, 177, 2421, 324.5, 941.3000000000012, 1723.1999999999998, 2418.4099999999985, 0.03412915701664752, 0.044831847349836834, 0.05539122188696014], "isController": true}, {"data": ["Upload Loan Forms", 200, 200, 100.0, 636.7249999999999, 314, 7430, 407.5, 1381.6, 1601.3499999999995, 3450.71, 0.06813662346918299, 0.17972365233424148, 0.0], "isController": false}, {"data": ["Edit Load Request", 100, 100, 100.0, 1170.0199999999998, 672, 7969, 939.0, 1759.6000000000008, 2127.9999999999986, 7933.379999999982, 0.03412523209423478, 0.16605024678088157, 0.11092999884742029], "isController": true}, {"data": ["ListActiveLoanTypes", 200, 0, 0.0, 408.27000000000004, 166, 3613, 292.0, 710.4000000000001, 922.1499999999999, 2582.480000000004, 0.06811392871945474, 0.187401439677283, 0.06764431510933817], "isController": false}, {"data": ["GetUserLoansAccessLevel", 100, 48, 48.0, 305.8099999999999, 1, 1841, 244.5, 449.6, 739.3999999999996, 1833.7099999999964, 0.034107761425759005, 0.030824889388529696, 0.03295629139403196], "isController": false}, {"data": ["Delete  Loan Request", 100, 48, 48.0, 558.0200000000001, 319, 1856, 485.0, 819.5, 1009.5999999999988, 1851.1799999999976, 0.034171211437787896, 0.08117164381039761, 0.09061144097008653], "isController": true}, {"data": ["HardDeleteLoan", 100, 48, 48.0, 261.15999999999997, 1, 985, 211.5, 393.10000000000014, 643.6999999999999, 982.7999999999988, 0.0341737688301738, 0.048353213069006064, 0.034308595027511594], "isController": false}, {"data": ["Get UserId from Token", 100, 47, 47.0, 30.650000000000006, 0, 2707, 2.0, 7.900000000000006, 13.849999999999966, 2680.219999999986, 0.034011766030340534, 0.0, 0.0], "isController": false}, {"data": ["Load Time Of Loans Page", 100, 49, 49.0, 2625.8699999999985, 1427, 8397, 2404.5, 3558.3, 5096.65, 8391.779999999997, 0.034025769075951985, 0.3135258636463239, 0.22525889835533042], "isController": true}, {"data": ["Create Loan Request", 100, 100, 100.0, 258.53, 1, 1158, 207.5, 385.80000000000007, 769.7499999999984, 1156.3199999999993, 0.034128178613235596, 0.042969509885226936, 0.06689056351595321], "isController": false}, {"data": ["Update Loan Request", 100, 100, 100.0, 245.14999999999998, 1, 950, 207.0, 353.9000000000001, 505.7999999999986, 949.7199999999998, 0.03415704178157665, 0.04330072175537136, 0.0547513363088671], "isController": false}, {"data": ["ListEmployeeIdentificationLN", 100, 47, 47.0, 883.9399999999999, 518, 3839, 713.0, 1665.7, 1935.249999999999, 3824.1899999999923, 0.03404040936996308, 0.031721738907507104, 0.0352467828621857], "isController": false}, {"data": ["GET_SINGLE_EMPLOYEE_LOANS", 500, 189, 37.8, 346.49800000000016, 150, 2421, 274.5, 533.5000000000002, 869.2999999999998, 1723.8400000000001, 0.169956514926091, 0.17582034663735935, 0.27848337614962837], "isController": false}, {"data": ["Send a Loan Request", 100, 100, 100.0, 1253.2900000000004, 679, 4041, 944.0, 2080.4, 3033.6999999999994, 4040.1899999999996, 0.03411725691795619, 0.16629164160469834, 0.12236300791213305], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 571, 69.0447400241838, 35.6875], "isController": false}, {"data": ["Non HTTP response code: java.io.FileNotFoundException/Non HTTP response message: C:\\\\Users\\\\PapaAsante\\\\OneDrive - AmaliTech gGmbH\\\\Documents\\\\Load Test for Employee Management\\\\171034461077917103390539531709745753793Selenium Notes (5).pdf (The system cannot find the path specified)", 200, 24.183796856106408, 12.5], "isController": false}, {"data": ["500/javax.script.ScriptException: java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 1", 47, 5.683192261185006, 2.9375], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: arms-microapi.amalitech-dev.net:443 failed to respond", 9, 1.0882708585247884, 0.5625], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1600, 827, "400/Bad Request", 571, "Non HTTP response code: java.io.FileNotFoundException/Non HTTP response message: C:\\\\Users\\\\PapaAsante\\\\OneDrive - AmaliTech gGmbH\\\\Documents\\\\Load Test for Employee Management\\\\171034461077917103390539531709745753793Selenium Notes (5).pdf (The system cannot find the path specified)", 200, "500/javax.script.ScriptException: java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 1", 47, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: arms-microapi.amalitech-dev.net:443 failed to respond", 9, "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GetUserDepartmentLN", 100, 48, "400/Bad Request", 47, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: arms-microapi.amalitech-dev.net:443 failed to respond", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Upload Loan Forms", 200, 200, "Non HTTP response code: java.io.FileNotFoundException/Non HTTP response message: C:\\\\Users\\\\PapaAsante\\\\OneDrive - AmaliTech gGmbH\\\\Documents\\\\Load Test for Employee Management\\\\171034461077917103390539531709745753793Selenium Notes (5).pdf (The system cannot find the path specified)", 200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GetUserLoansAccessLevel", 100, 48, "400/Bad Request", 47, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: arms-microapi.amalitech-dev.net:443 failed to respond", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["HardDeleteLoan", 100, 48, "400/Bad Request", 47, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: arms-microapi.amalitech-dev.net:443 failed to respond", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Get UserId from Token", 100, 47, "500/javax.script.ScriptException: java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 1", 47, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Create Loan Request", 100, 100, "400/Bad Request", 98, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: arms-microapi.amalitech-dev.net:443 failed to respond", 2, "", "", "", "", "", ""], "isController": false}, {"data": ["Update Loan Request", 100, 100, "400/Bad Request", 97, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: arms-microapi.amalitech-dev.net:443 failed to respond", 3, "", "", "", "", "", ""], "isController": false}, {"data": ["ListEmployeeIdentificationLN", 100, 47, "400/Bad Request", 47, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GET_SINGLE_EMPLOYEE_LOANS", 500, 189, "400/Bad Request", 188, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: arms-microapi.amalitech-dev.net:443 failed to respond", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
